import Search from 'react-search'
import ReactDOM from 'react-dom'
import React, { Component,PropTypes  } from 'react'
import Select from 'react-select';
 
class TestComponent extends Component {
    state = {selectedOption:'',repos:[],value:[]}
    
  handleChange = (selectedOption) => {
    this.setState({ selectedOption });
    console.log(`Selected: ${selectedOption.login}`);
  }

  componentDidMount() {
      fetch("https://api.github.com/search/users?q=query")
        .then(res => res.json())
        .then(
          (result) => {
            this.setState({
              repos: result.items
            });
           
            for (var i = 0; i < result.items.length; i++) {
              console.log(result.items[i]+'!!!!');
              result.items[i].label = result.items[i].login;
              result.items[i].value = result.items[i].login;
              }
            console.log(result.items);
          },
          (error) => {
            this.setState({
              error
            });
          }
        )
      
    }


  render() {
    const { selectedOption } = this.state;
    const value = selectedOption && selectedOption.login;

    return (
      <div>
      <Select
        name="form-field-name"
        value={value}
        onChange={this.handleChange}
        options = {this.state.repos}
       
      />
      </div>
    );
  }
}
 
ReactDOM.render( <TestComponent />, document.getElementById('root'))